const userModel = require("../model/userSchema");

const registerUser = (req, res, next) => {
  const user = new userModel(req.body);
  user
    .save()
    .then((r) => {
      res.redirect("/");
    })
    .catch((err) => {
      console.log(err);
    });
};

const loginUser = (req, res, next) => {
  const user = userModel.findOne(req.body);
  user.then((u) => {
    req.session.regenerate(function (err) {
      if (err) next(err);

      // store user information in session, typically a user id
      req.session.user = u;

      // save the session before redirection to ensure page
      // load does not happen before session is saved
      req.session.save(function (err) {
        if (err) return next(err);
        res.redirect("/home");
      });
    });
  });
};

module.exports = { registerUser, loginUser };
