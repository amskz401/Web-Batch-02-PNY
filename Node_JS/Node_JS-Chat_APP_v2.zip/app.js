const express = require("express");
const { createServer } = require("http");
const expressLayouts = require("express-ejs-layouts");
const session = require("express-session");
const { Server } = require("socket.io");
require("./server/config");

const app = express();

const server = createServer(app);

const io = new Server(server);

const port = 3000;

app.use(
  session({
    secret: "chat_app_session",
    resave: true,
    saveUninitialized: true,
    cookie: {
      maxAge: 1000 * 60 * 60,
    },
  })
);

// default values
app.use((req, res, next) => {
  let setUser = "";
  if (req.session?.user) {
    setUser = req.session?.user;
  }
  app.locals = {
    setUser: setUser,
  };
  next();
});

// default view engine
app.use(expressLayouts);
app.set("layout", "./layouts/app");
app.set("view engine", "ejs");

// load static files
app.use(express.static("public"));

// get form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// user router
app.use("/", require("./routes/user"));

// setting out socket.io
io.on("connection", (socket) => {
  // user has joined the chat
  console.log(socket);
  socket.on("start-chat", (user) => {
    socket.broadcast.emit("start-chat", {
      msg: "New User Joined Chat " + user.from,
      fromSer: user.from,
      bit: "new",
    });
    io.emit("start-chat", { msg: user.msg, fromSer: user.from });
  });
});

server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
